Mongoose models go here
