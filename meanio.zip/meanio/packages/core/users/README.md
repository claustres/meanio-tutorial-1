README: meanUser
