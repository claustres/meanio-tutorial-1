'use strict';

angular.module('mean.theme').factory('Theme', [
  function() {
    return {
      name: 'theme'
    };
  }
]);
